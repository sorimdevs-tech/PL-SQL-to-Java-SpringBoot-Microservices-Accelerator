-- ============================================
-- EMPLOYEE CRUD - SINGLE FILE (RUNTIME MENU)
-- ============================================

SET SERVEROUTPUT ON;

-- ============================================
-- 1. CLEANUP (IGNORE ERRORS)
-- ============================================

BEGIN EXECUTE IMMEDIATE 'DROP TABLE employees'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP SEQUENCE emp_seq'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP PACKAGE emp_pkg'; EXCEPTION WHEN OTHERS THEN NULL; END;
/
BEGIN EXECUTE IMMEDIATE 'DROP DIRECTORY emp_img_dir'; EXCEPTION WHEN OTHERS THEN NULL; END;
/

-- ============================================
-- 2. DIRECTORY (CHANGE PATH!)
-- ============================================

CREATE OR REPLACE DIRECTORY emp_img_dir AS '/path/to/your/images';
GRANT READ, WRITE ON DIRECTORY emp_img_dir TO PUBLIC;

-- ============================================
-- 3. TABLE
-- ============================================

CREATE TABLE employees (
    emp_id     NUMBER PRIMARY KEY,
    name       VARCHAR2(100),
    email      VARCHAR2(100) UNIQUE,
    salary     NUMBER,
    address    VARCHAR2(200),
    image      BLOB,
    created_at DATE DEFAULT SYSDATE
);

-- ============================================
-- 4. SEQUENCE
-- ============================================

CREATE SEQUENCE emp_seq START WITH 1 INCREMENT BY 1;

-- ============================================
-- 5. PACKAGE SPEC
-- ============================================

CREATE OR REPLACE PACKAGE emp_pkg AS
    PROCEDURE add_employee;
    PROCEDURE update_employee;
    PROCEDURE delete_employee;
    PROCEDURE get_employee;
END emp_pkg;
/

-- ============================================
-- 6. PACKAGE BODY
-- ============================================

CREATE OR REPLACE PACKAGE BODY emp_pkg AS

-- IMAGE LOAD FUNCTION
FUNCTION load_image(p_filename VARCHAR2) RETURN BLOB IS
    v_bfile BFILE;
    v_blob  BLOB;
BEGIN
    v_bfile := BFILENAME('EMP_IMG_DIR', p_filename);

    DBMS_LOB.CREATETEMPORARY(v_blob, TRUE);
    DBMS_LOB.FILEOPEN(v_bfile, DBMS_LOB.FILE_READONLY);

    DBMS_LOB.LOADFROMFILE(v_blob, v_bfile, DBMS_LOB.GETLENGTH(v_bfile));

    DBMS_LOB.FILECLOSE(v_bfile);

    RETURN v_blob;

EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Image load failed: ' || SQLERRM);
        RETURN NULL;
END;

-- ADD
PROCEDURE add_employee IS
    v_name    VARCHAR2(100);
    v_email   VARCHAR2(100);
    v_salary  NUMBER;
    v_address VARCHAR2(200);
    v_file    VARCHAR2(100);
BEGIN
    v_name    := '&Enter_Name';
    v_email   := '&Enter_Email';
    v_salary  := &Enter_Salary;
    v_address := '&Enter_Address';
    v_file    := '&Enter_Image_File';

    INSERT INTO employees
    VALUES (
        emp_seq.NEXTVAL,
        v_name,
        v_email,
        v_salary,
        v_address,
        load_image(v_file),
        SYSDATE
    );

    DBMS_OUTPUT.PUT_LINE('✅ Employee Added');

EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('❌ Email already exists');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('❌ Error: ' || SQLERRM);
END;

-- UPDATE
PROCEDURE update_employee IS
    v_id      NUMBER;
    v_name    VARCHAR2(100);
    v_email   VARCHAR2(100);
    v_salary  NUMBER;
    v_address VARCHAR2(200);
BEGIN
    v_id      := &Enter_ID;
    v_name    := '&New_Name';
    v_email   := '&New_Email';
    v_salary  := &New_Salary;
    v_address := '&New_Address';

    UPDATE employees
    SET name = v_name,
        email = v_email,
        salary = v_salary,
        address = v_address
    WHERE emp_id = v_id;

    IF SQL%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('❌ Employee Not Found');
    ELSE
        DBMS_OUTPUT.PUT_LINE('✅ Employee Updated');
    END IF;

END;

-- DELETE
PROCEDURE delete_employee IS
    v_id NUMBER;
BEGIN
    v_id := &Delete_ID;

    DELETE FROM employees WHERE emp_id = v_id;

    IF SQL%ROWCOUNT = 0 THEN
        DBMS_OUTPUT.PUT_LINE('❌ Employee Not Found');
    ELSE
        DBMS_OUTPUT.PUT_LINE('✅ Employee Deleted');
    END IF;

END;

-- READ
PROCEDURE get_employee IS
    v_id  NUMBER;
    v_rec employees%ROWTYPE;
BEGIN
    v_id := &View_ID;

    SELECT * INTO v_rec FROM employees WHERE emp_id = v_id;

    DBMS_OUTPUT.PUT_LINE('---------------------------');
    DBMS_OUTPUT.PUT_LINE('ID      : ' || v_rec.emp_id);
    DBMS_OUTPUT.PUT_LINE('Name    : ' || v_rec.name);
    DBMS_OUTPUT.PUT_LINE('Email   : ' || v_rec.email);
    DBMS_OUTPUT.PUT_LINE('Salary  : ' || v_rec.salary);
    DBMS_OUTPUT.PUT_LINE('Address : ' || v_rec.address);
    DBMS_OUTPUT.PUT_LINE('---------------------------');

EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('❌ Employee Not Found');
END;

END emp_pkg;
/

-- ============================================
-- 7. MENU DRIVER
-- ============================================

DECLARE
    v_choice NUMBER;
BEGIN
    DBMS_OUTPUT.PUT_LINE('==============================');
    DBMS_OUTPUT.PUT_LINE(' EMPLOYEE MANAGEMENT SYSTEM');
    DBMS_OUTPUT.PUT_LINE('==============================');
    DBMS_OUTPUT.PUT_LINE('1 → Add Employee');
    DBMS_OUTPUT.PUT_LINE('2 → Edit Employee');
    DBMS_OUTPUT.PUT_LINE('3 → Delete Employee');
    DBMS_OUTPUT.PUT_LINE('4 → View Employee');
    DBMS_OUTPUT.PUT_LINE('==============================');

    v_choice := &Enter_Choice;

    IF v_choice = 1 THEN
        emp_pkg.add_employee;

    ELSIF v_choice = 2 THEN
        emp_pkg.update_employee;

    ELSIF v_choice = 3 THEN
        emp_pkg.delete_employee;

    ELSIF v_choice = 4 THEN
        emp_pkg.get_employee;

    ELSE
        DBMS_OUTPUT.PUT_LINE('❌ Invalid Choice');
    END IF;

END;
/