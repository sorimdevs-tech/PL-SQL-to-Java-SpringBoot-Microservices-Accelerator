-- =========================================
-- SCHEMA DEFINITIONS
-- =========================================
 
CREATE TABLE customers (
    customer_id NUMBER PRIMARY KEY,
    status      VARCHAR2(20)
);
 
CREATE TABLE orders (
    order_id    NUMBER PRIMARY KEY,
    customer_id NUMBER,
    amount      NUMBER(10,2),
    CONSTRAINT fk_orders_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);
 
CREATE TABLE payments (
    payment_id  NUMBER PRIMARY KEY,
    customer_id NUMBER,
    amount      NUMBER(10,2),
    CONSTRAINT fk_payments_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);
 
CREATE TABLE customer_balance (
    balance_id  NUMBER PRIMARY KEY,
    customer_id NUMBER,
    balance     NUMBER(10,2),
    created_at  DATE,
    updated_at  DATE,
    CONSTRAINT fk_balance_customer
        FOREIGN KEY (customer_id)
        REFERENCES customers(customer_id)
);
 
CREATE TABLE balance_audit_log (
    audit_id    NUMBER PRIMARY KEY,
    customer_id NUMBER,
    old_balance NUMBER(10,2),
    new_balance NUMBER(10,2),
    action_date DATE
);
 
CREATE TABLE error_log (
    error_id      NUMBER PRIMARY KEY,
    error_message VARCHAR2(500),
    error_date    DATE
);
 
-- =========================================
-- SEQUENCES
-- =========================================
 
CREATE SEQUENCE balance_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE audit_seq START WITH 1 INCREMENT BY 1;
CREATE SEQUENCE error_seq START WITH 1 INCREMENT BY 1;
 
-- =========================================
-- PROCEDURE
-- =========================================
 
CREATE OR REPLACE PROCEDURE reconcile_customer_balances (
    p_batch_size     IN NUMBER DEFAULT 100,
    p_run_mode       IN VARCHAR2 DEFAULT 'FULL'
)
IS
    CURSOR cust_cursor IS
        SELECT customer_id
        FROM customers
        WHERE status = 'ACTIVE'
        FOR UPDATE SKIP LOCKED;
 
    TYPE cust_table IS TABLE OF cust_cursor%ROWTYPE;
    v_customers cust_table;
 
    v_total_orders   NUMBER;
    v_total_payments NUMBER;
    v_balance        NUMBER;
    v_limit          NUMBER := p_batch_size;
 
    v_has_error      BOOLEAN := FALSE;
 
    e_balance_error EXCEPTION;
 
BEGIN
    OPEN cust_cursor;
 
    LOOP
        FETCH cust_cursor BULK COLLECT INTO v_customers LIMIT v_limit;
        EXIT WHEN v_customers.COUNT = 0;
 
        SAVEPOINT batch_start;
 
        FOR i IN 1 .. v_customers.COUNT LOOP
            BEGIN
                -- Aggregation
                SELECT NVL(SUM(o.amount), 0)
                INTO v_total_orders
                FROM orders o
                WHERE o.customer_id = v_customers(i).customer_id;
 
                SELECT NVL(SUM(p.amount), 0)
                INTO v_total_payments
                FROM payments p
                WHERE p.customer_id = v_customers(i).customer_id;
 
                v_balance := v_total_orders - v_total_payments;
 
                -- Validation
                IF v_balance < 0 THEN
                    RAISE e_balance_error;
                END IF;
 
                -- MERGE (UPSERT)
                MERGE INTO customer_balance cb
                USING dual
                ON (cb.customer_id = v_customers(i).customer_id)
                WHEN MATCHED THEN
                    UPDATE SET balance = v_balance,
                               updated_at = SYSDATE
                WHEN NOT MATCHED THEN
                    INSERT (balance_id, customer_id, balance, created_at)
                    VALUES (balance_seq.NEXTVAL,
                            v_customers(i).customer_id,
                            v_balance,
                            SYSDATE);
 
                -- Audit log
                INSERT INTO balance_audit_log (
                    audit_id,
                    customer_id,
                    old_balance,
                    new_balance,
                    action_date
                )
                VALUES (
                    audit_seq.NEXTVAL,
                    v_customers(i).customer_id,
                    NULL,
                    v_balance,
                    SYSDATE
                );
 
            EXCEPTION
                WHEN e_balance_error THEN
                    v_has_error := TRUE;
 
                    INSERT INTO error_log (
                        error_id,
                        error_message,
                        error_date
                    )
                    VALUES (
                        error_seq.NEXTVAL,
                        'Negative balance for customer '
                        || v_customers(i).customer_id,
                        SYSDATE
                    );
 
                WHEN OTHERS THEN
                    v_has_error := TRUE;
 
                    INSERT INTO error_log (
                        error_id,
                        error_message,
                        error_date
                    )
                    VALUES (
                        error_seq.NEXTVAL,
                        'Unexpected error: ' || SQLERRM,
                        SYSDATE
                    );
            END;
        END LOOP;
 
        -- Conditional transaction
        IF p_run_mode = 'FULL' AND NOT v_has_error THEN
            COMMIT;
        ELSE
            ROLLBACK TO batch_start;
        END IF;
 
    END LOOP;
 
    CLOSE cust_cursor;
 
EXCEPTION
    WHEN OTHERS THEN
        ROLLBACK;
 
        INSERT INTO error_log (
            error_id,
            error_message,
            error_date
        )
        VALUES (
            error_seq.NEXTVAL,
            'Fatal reconcile error: ' || SQLERRM,
            SYSDATE
        );
END reconcile_customer_balances;
/