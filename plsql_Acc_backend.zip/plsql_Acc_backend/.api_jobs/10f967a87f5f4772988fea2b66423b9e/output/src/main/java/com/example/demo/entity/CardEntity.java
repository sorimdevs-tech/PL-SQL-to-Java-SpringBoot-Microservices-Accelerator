package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "CARD")
public class CardEntity {

    @Id
    @SequenceGenerator(name = "seq_cardid", sequenceName = "card_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_cardid")
    @Column(name = "CARDID")
    private Long cardid;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "BALANCE")
    private Long balance;

    public Long getCardid() {
        return cardid;
    }

    public void setCardid(Long cardid) {
        this.cardid = cardid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getBalance() {
        return balance;
    }

    public void setBalance(Long balance) {
        this.balance = balance;
    }
}
