package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.example.demo.entity.CustomerEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface CustomerRepository extends JpaRepository<CustomerEntity, Long> {

    Optional<CustomerEntity> findByUsername(String username);

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO customer (CUSTOMERID, NAME, USERNAME, PASSWORD, CARDNUMBER) VALUES (customer_seq.NEXTVAL, :name, :username, :password, :cardnumber)", nativeQuery = true)
    void insertCustomer(
                      @Param("name") String name,
                      @Param("username") String username,
                      @Param("password") String password,
                      @Param("cardnumber") Long cardnumber);


    @Modifying
    @Transactional
    @Query(value = "DELETE FROM customer WHERE customerid = :customerid", nativeQuery = true)
    int deleteCustomerByCustomerid(@Param("customerid") Long customerid);

}
