package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entity.CardEntity;
import com.example.demo.entity.CustomerEntity;
import com.example.demo.repository.CardRepository;
import com.example.demo.repository.CustomerRepository;
import com.example.demo.exception.BusinessException;

@Service
public class LogincustomerBankService {

    private final CustomerRepository customerRepository;
    private final CardRepository cardRepository;

    public LogincustomerBankService(CustomerRepository customerRepository, CardRepository cardRepository) {
        this.customerRepository = customerRepository;
        this.cardRepository = cardRepository;
    }

public void logincustomerBank(String user, String pass) {
    // === Derived Values Layer ===
    // === Database Operations ===
    var p = customerRepository.findOne(username=user).orElse(null);
    }

    private void saveErrorRecord(String message) {
        // No error table discovered for this unit.
    }

    private String safeMessage(Exception exception) {
        return exception.getMessage() != null ? exception.getMessage() : exception.getClass().getSimpleName();
    }
}
