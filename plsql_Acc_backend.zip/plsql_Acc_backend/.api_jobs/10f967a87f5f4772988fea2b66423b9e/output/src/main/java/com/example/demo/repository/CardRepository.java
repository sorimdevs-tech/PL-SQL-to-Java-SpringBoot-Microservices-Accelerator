package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.CardEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface CardRepository extends JpaRepository<CardEntity, Long> {
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO card (CARDID, STATUS, BALANCE) VALUES (card_seq.NEXTVAL, :status, :balance)", nativeQuery = true)
    void insertCard(
                      @Param("status") String status,
                      @Param("balance") Long balance);


    @Modifying
    @Transactional
    @Query(value = "DELETE FROM card WHERE cardid = :cardid", nativeQuery = true)
    int deleteCardByCardid(@Param("cardid") Long cardid);

}
