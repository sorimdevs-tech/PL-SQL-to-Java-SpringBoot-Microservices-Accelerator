-- ============================================================
-- HOSPITAL MANAGEMENT SYSTEM - COMPLETE SQL SCRIPT
-- ============================================================

-- SECTION 1: DROP TABLES
DROP TABLE Treatment;
DROP TABLE Medicine;
DROP TABLE Doctor;
DROP TABLE Patient;
DROP TABLE Department;
DROP TABLE Ward;
DROP TABLE Insurance;

-- SECTION 2: CREATE TABLES

CREATE TABLE Insurance(
  insuranceID NUMBER PRIMARY KEY,
  status VARCHAR2(1) CHECK (status IN ('A','B')),
  coverage NUMBER
);

CREATE TABLE Patient(
  patientID NUMBER PRIMARY KEY,
  name VARCHAR2(40),
  address VARCHAR2(50),
  phone NUMBER(10),
  password VARCHAR2(20),
  username VARCHAR2(10),
  dateRegistered DATE,
  insuranceNumber NUMBER
);

CREATE TABLE Doctor(
  doctorID NUMBER PRIMARY KEY,
  name VARCHAR2(40),
  specialization VARCHAR2(50),
  phone NUMBER(10),
  password VARCHAR2(20),
  username VARCHAR2(10),
  salary NUMBER(10,2),
  departmentName VARCHAR2(40),
  insuranceNumber NUMBER
);

CREATE TABLE Department(
  name VARCHAR2(40) PRIMARY KEY,
  location VARCHAR2(50),
  phone NUMBER(10)
);

CREATE TABLE Ward(
  location VARCHAR2(50) PRIMARY KEY
);

CREATE TABLE Treatment(
  insuranceID NUMBER,
  treatmentID VARCHAR2(6),
  admissionDate DATE,
  dischargeDate DATE,
  PRIMARY KEY (insuranceID, treatmentID)
);

CREATE TABLE Medicine(
  medCode VARCHAR2(4),
  medicineID VARCHAR2(6),
  condition VARCHAR2(10),
  availability VARCHAR2(1) CHECK (availability IN ('A','O')),
  cost NUMBER(10,2),
  penalty NUMBER(10,2),
  location VARCHAR2(50),
  PRIMARY KEY (medCode, medicineID)
);

-- SECTION 3: FOREIGN KEYS

ALTER TABLE Patient
ADD FOREIGN KEY (insuranceNumber) REFERENCES Insurance(insuranceID);

ALTER TABLE Doctor
ADD FOREIGN KEY (insuranceNumber) REFERENCES Insurance(insuranceID);

ALTER TABLE Doctor
ADD FOREIGN KEY (departmentName) REFERENCES Department(name);

ALTER TABLE Department
ADD FOREIGN KEY (location) REFERENCES Ward(location);

ALTER TABLE Medicine
ADD FOREIGN KEY (location) REFERENCES Ward(location);

ALTER TABLE Treatment
ADD FOREIGN KEY (insuranceID) REFERENCES Insurance(insuranceID);

-- SECTION 4: INSERT DATA

INSERT INTO Insurance VALUES (201,'A',0);
INSERT INTO Insurance VALUES (202,'A',0);

INSERT INTO Ward VALUES ('BLOCK A');
INSERT INTO Ward VALUES ('BLOCK B');

INSERT INTO Department VALUES ('CARDIOLOGY','BLOCK A',9876543210);
INSERT INTO Department VALUES ('NEUROLOGY','BLOCK B',8765432109);

INSERT INTO Patient VALUES (1,'RAJ','CHENNAI',9876543210,'raj123','ra1',SYSDATE,201);
INSERT INTO Patient VALUES (2,'ANU','MADURAI',8765432109,'anu123','an2',SYSDATE,202);

INSERT INTO Doctor VALUES (101,'DR.KUMAR','CARDIO',9999999999,'doc123','dk1',50000,'CARDIOLOGY',201);

INSERT INTO Medicine VALUES ('M101','MED1','GOOD','A',50,200,'BLOCK A');

INSERT INTO Treatment VALUES (201,'MED1',SYSDATE,SYSDATE+5);

-- SECTION 5: SAMPLE SELECT

SELECT * FROM Patient;
SELECT * FROM Doctor;
SELECT * FROM Medicine;

-- SECTION 6: PROCEDURE

CREATE OR REPLACE PROCEDURE loginPatient_hospital(user IN VARCHAR2, pass IN VARCHAR2)
IS
  passAux VARCHAR2(20);
BEGIN
  SELECT password INTO passAux FROM patient WHERE username = user;

  IF passAux = pass THEN
    DBMS_OUTPUT.PUT_LINE('Login successful');
  ELSE
    DBMS_OUTPUT.PUT_LINE('Wrong password');
  END IF;
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    DBMS_OUTPUT.PUT_LINE('User not found');
END;
/

-- SECTION 7: TRIGGER

CREATE OR REPLACE TRIGGER addInsurance_patient
AFTER INSERT ON patient
FOR EACH ROW
BEGIN
  INSERT INTO insurance VALUES(:NEW.insuranceNumber,'A',0);
END;
/

-- SECTION 8: OBJECT TYPE

CREATE OR REPLACE TYPE headDoctor_obj AS OBJECT(
  doctorID NUMBER,
  name VARCHAR2(40),
  specialization VARCHAR2(50),
  salary NUMBER,
  bonus NUMBER
);
/
