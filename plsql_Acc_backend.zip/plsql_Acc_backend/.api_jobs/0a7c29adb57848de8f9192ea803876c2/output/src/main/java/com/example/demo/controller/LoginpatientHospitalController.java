package com.example.demo.controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.http.ResponseEntity;
import org.springframework.beans.factory.annotation.Autowired;
import com.example.demo.service.LoginpatientHospitalService;

@RestController
@RequestMapping("/api/loginpatienthospital")
public class LoginpatientHospitalController {

    @Autowired
    private LoginpatientHospitalService loginpatientHospitalService;

    /**
     * Action-dispatch endpoint.
     * Pass a JSON body with an "action" field (INSERT / UPDATE / DELETE / SELECT)
     * plus the procedure parameters.
     */
    @PostMapping("/action")
    public ResponseEntity<?> executeAction(@RequestBody LoginpatientHospitalActionRequest request) {
        loginpatientHospitalService.loginpatientHospital(request.getUser(), request.getPass());
        return ResponseEntity.ok().build();
    }

    /**
     * Request DTO for action-dispatch.
     */
    public static class LoginpatientHospitalActionRequest {
        private String user;
        private String pass;

        public String getUser() { return user; }
        public void setUser(String user) { this.user = user; }
        public String getPass() { return pass; }
        public void setPass(String pass) { this.pass = pass; }
    }
}
