package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "WARD")
public class WardEntity {

    @Id
    @Column(name = "LOCATION")
    private String location;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
