package com.example.demo.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "TREATMENT")
public class TreatmentEntity {

    @Id
    @SequenceGenerator(name = "seq_insuranceid", sequenceName = "treatment_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_insuranceid")
    @Column(name = "INSURANCEID")
    private Long insuranceid;

    @Column(name = "TREATMENTID")
    private String treatmentid;

    @Column(name = "ADMISSIONDATE")
    private LocalDateTime admissiondate;

    @Column(name = "DISCHARGEDATE")
    private LocalDateTime dischargedate;

    public Long getInsuranceid() {
        return insuranceid;
    }

    public void setInsuranceid(Long insuranceid) {
        this.insuranceid = insuranceid;
    }

    public String getTreatmentid() {
        return treatmentid;
    }

    public void setTreatmentid(String treatmentid) {
        this.treatmentid = treatmentid;
    }

    public LocalDateTime getAdmissiondate() {
        return admissiondate;
    }

    public void setAdmissiondate(LocalDateTime admissiondate) {
        this.admissiondate = admissiondate;
    }

    public LocalDateTime getDischargedate() {
        return dischargedate;
    }

    public void setDischargedate(LocalDateTime dischargedate) {
        this.dischargedate = dischargedate;
    }
}
