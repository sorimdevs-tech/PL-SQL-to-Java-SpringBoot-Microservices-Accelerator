package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.demo.entity.InsuranceEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

@Repository
public interface InsuranceRepository extends JpaRepository<InsuranceEntity, Long> {
    @Modifying
    @Transactional
    @Query(value = "INSERT INTO insurance (INSURANCEID, STATUS, COVERAGE) VALUES (insurance_seq.NEXTVAL, :status, :coverage)", nativeQuery = true)
    void insertInsurance(
                      @Param("status") String status,
                      @Param("coverage") Long coverage);


    @Modifying
    @Transactional
    @Query(value = "DELETE FROM insurance WHERE insuranceid = :insuranceid", nativeQuery = true)
    int deleteInsuranceByInsuranceid(@Param("insuranceid") Long insuranceid);

}
