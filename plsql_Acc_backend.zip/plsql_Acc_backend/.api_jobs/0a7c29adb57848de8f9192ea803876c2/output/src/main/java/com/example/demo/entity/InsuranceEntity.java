package com.example.demo.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "INSURANCE")
public class InsuranceEntity {

    @Id
    @SequenceGenerator(name = "seq_insuranceid", sequenceName = "insurance_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_insuranceid")
    @Column(name = "INSURANCEID")
    private Long insuranceid;

    @Column(name = "STATUS")
    private String status;

    @Column(name = "COVERAGE")
    private Long coverage;

    public Long getInsuranceid() {
        return insuranceid;
    }

    public void setInsuranceid(Long insuranceid) {
        this.insuranceid = insuranceid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getCoverage() {
        return coverage;
    }

    public void setCoverage(Long coverage) {
        this.coverage = coverage;
    }
}
