package com.example.demo.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "PATIENT")
public class PatientEntity {

    @Id
    @SequenceGenerator(name = "seq_patientid", sequenceName = "patient_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_patientid")
    @Column(name = "PATIENTID")
    private Long patientid;

    @Column(name = "NAME")
    private String name;

    @Column(name = "ADDRESS")
    private String address;

    @Column(name = "PHONE")
    private Long phone;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "USERNAME")
    private String username;

    @Column(name = "DATEREGISTERED")
    private LocalDateTime dateregistered;

    @Column(name = "INSURANCENUMBER")
    private Long insurancenumber;

    public Long getPatientid() {
        return patientid;
    }

    public void setPatientid(Long patientid) {
        this.patientid = patientid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Long getPhone() {
        return phone;
    }

    public void setPhone(Long phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public LocalDateTime getDateregistered() {
        return dateregistered;
    }

    public void setDateregistered(LocalDateTime dateregistered) {
        this.dateregistered = dateregistered;
    }

    public Long getInsurancenumber() {
        return insurancenumber;
    }

    public void setInsurancenumber(Long insurancenumber) {
        this.insurancenumber = insurancenumber;
    }
}
