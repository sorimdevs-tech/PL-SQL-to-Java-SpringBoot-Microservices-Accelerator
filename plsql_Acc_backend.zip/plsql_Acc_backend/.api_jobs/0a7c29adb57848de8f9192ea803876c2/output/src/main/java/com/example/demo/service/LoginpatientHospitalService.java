package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.example.demo.entity.InsuranceEntity;
import com.example.demo.entity.PatientEntity;
import com.example.demo.repository.InsuranceRepository;
import com.example.demo.repository.PatientRepository;
import com.example.demo.exception.BusinessException;

@Service
public class LoginpatientHospitalService {

    private final PatientRepository patientRepository;
    private final InsuranceRepository insuranceRepository;

    public LoginpatientHospitalService(PatientRepository patientRepository, InsuranceRepository insuranceRepository) {
        this.patientRepository = patientRepository;
        this.insuranceRepository = insuranceRepository;
    }

public void loginpatientHospital(String user, String pass) {
    // === Derived Values Layer ===
    // === Database Operations ===
    var passaux = patientRepository.findOne(username = user).orElse(null);
    }

    private void saveErrorRecord(String message) {
        // No error table discovered for this unit.
    }

    private String safeMessage(Exception exception) {
        return exception.getMessage() != null ? exception.getMessage() : exception.getClass().getSimpleName();
    }
}
