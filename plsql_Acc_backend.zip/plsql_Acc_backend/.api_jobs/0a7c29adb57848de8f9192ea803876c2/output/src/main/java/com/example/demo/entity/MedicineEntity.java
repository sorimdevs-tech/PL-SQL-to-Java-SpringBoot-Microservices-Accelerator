package com.example.demo.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "MEDICINE")
public class MedicineEntity {

    @Id
    @Column(name = "MEDCODE")
    private String medcode;

    @Column(name = "MEDICINEID")
    private String medicineid;

    @Column(name = "CONDITION")
    private String condition;

    @Column(name = "AVAILABILITY")
    private String availability;

    @Column(name = "COST")
    private BigDecimal cost;

    @Column(name = "PENALTY")
    private BigDecimal penalty;

    @Column(name = "LOCATION")
    private String location;

    public String getMedcode() {
        return medcode;
    }

    public void setMedcode(String medcode) {
        this.medcode = medcode;
    }

    public String getMedicineid() {
        return medicineid;
    }

    public void setMedicineid(String medicineid) {
        this.medicineid = medicineid;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public String getAvailability() {
        return availability;
    }

    public void setAvailability(String availability) {
        this.availability = availability;
    }

    public BigDecimal getCost() {
        return cost;
    }

    public void setCost(BigDecimal cost) {
        this.cost = cost;
    }

    public BigDecimal getPenalty() {
        return penalty;
    }

    public void setPenalty(BigDecimal penalty) {
        this.penalty = penalty;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }
}
