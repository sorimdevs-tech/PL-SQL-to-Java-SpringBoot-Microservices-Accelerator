package com.example.demo.entity;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "DOCTOR")
public class DoctorEntity {

    @Id
    @SequenceGenerator(name = "seq_doctorid", sequenceName = "doctor_seq", allocationSize = 1)
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "seq_doctorid")
    @Column(name = "DOCTORID")
    private Long doctorid;

    @Column(name = "NAME")
    private String name;

    @Column(name = "SPECIALIZATION")
    private String specialization;

    @Column(name = "PHONE")
    private Long phone;

    @Column(name = "PASSWORD")
    private String password;

    @Column(name = "USERNAME")
    private String username;

    @Column(name = "SALARY")
    private BigDecimal salary;

    @Column(name = "DEPARTMENTNAME")
    private String departmentname;

    @Column(name = "INSURANCENUMBER")
    private Long insurancenumber;

    public Long getDoctorid() {
        return doctorid;
    }

    public void setDoctorid(Long doctorid) {
        this.doctorid = doctorid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Long getPhone() {
        return phone;
    }

    public void setPhone(Long phone) {
        this.phone = phone;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public String getDepartmentname() {
        return departmentname;
    }

    public void setDepartmentname(String departmentname) {
        this.departmentname = departmentname;
    }

    public Long getInsurancenumber() {
        return insurancenumber;
    }

    public void setInsurancenumber(Long insurancenumber) {
        this.insurancenumber = insurancenumber;
    }
}
