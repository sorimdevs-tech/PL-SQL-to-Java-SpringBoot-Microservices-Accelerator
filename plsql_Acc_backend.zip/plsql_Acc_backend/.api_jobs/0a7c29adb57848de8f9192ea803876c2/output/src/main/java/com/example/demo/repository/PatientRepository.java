package com.example.demo.repository;

import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;
import com.example.demo.entity.PatientEntity;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.time.LocalDateTime;
import java.time.LocalDate;

@Repository
public interface PatientRepository extends JpaRepository<PatientEntity, Long> {

    Optional<PatientEntity> findByUsername(String username);

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO patient (PATIENTID, NAME, ADDRESS, PHONE, PASSWORD, USERNAME, DATEREGISTERED, INSURANCENUMBER) VALUES (patient_seq.NEXTVAL, :name, :address, :phone, :password, :username, :dateregistered, :insurancenumber)", nativeQuery = true)
    void insertPatient(
                      @Param("name") String name,
                      @Param("address") String address,
                      @Param("phone") Long phone,
                      @Param("password") String password,
                      @Param("username") String username,
                      @Param("dateregistered") LocalDateTime dateregistered,
                      @Param("insurancenumber") Long insurancenumber);


    @Modifying
    @Transactional
    @Query(value = "DELETE FROM patient WHERE patientid = :patientid", nativeQuery = true)
    int deletePatientByPatientid(@Param("patientid") Long patientid);

}
