# demo

Auto-generated Spring Boot application from PL/SQL modernization.

## Project Info

- **Package**: com.example.demo
- **Java**: 21
- **Spring Boot**: 3.2.5
- **Generated**: 2026-03-31 15:39:44

## Quick Start

1. Edit `src/main/resources/application.properties` with your DB credentials
2. Run the SQL DDL against your Oracle schema
3. `mvn clean package && java -jar target/demo-1.0.0.jar`

## API Docs

Swagger UI: `http://localhost:8080/swagger-ui/index.html`
