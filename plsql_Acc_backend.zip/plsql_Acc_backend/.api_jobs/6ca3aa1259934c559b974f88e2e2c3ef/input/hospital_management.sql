-- HOSPITAL MANAGEMENT SYSTEM SQL SCRIPT

CREATE TABLE Insurance(insuranceID NUMBER PRIMARY KEY, status VARCHAR2(1), coverage NUMBER);
CREATE TABLE Patient(patientID NUMBER PRIMARY KEY, name VARCHAR2(40), username VARCHAR2(10), password VARCHAR2(20), insuranceNumber NUMBER);

ALTER TABLE Patient ADD FOREIGN KEY(insuranceNumber) REFERENCES Insurance(insuranceID);

INSERT INTO Insurance VALUES (1,'A',0);
INSERT INTO Patient VALUES (1,'ANU','an1','anu123',1);

CREATE OR REPLACE PROCEDURE loginPatient(user IN VARCHAR2, pass IN VARCHAR2)
IS p VARCHAR2(20);
BEGIN
 SELECT password INTO p FROM patient WHERE username=user;
 IF p=pass THEN DBMS_OUTPUT.PUT_LINE('Login Success'); END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_insurance
AFTER INSERT ON patient
FOR EACH ROW
BEGIN
 INSERT INTO insurance VALUES(:NEW.insuranceNumber,'A',0);
END;
/
