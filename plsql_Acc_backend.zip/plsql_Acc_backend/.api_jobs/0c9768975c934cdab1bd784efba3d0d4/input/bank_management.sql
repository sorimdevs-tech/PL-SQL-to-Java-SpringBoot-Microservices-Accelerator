-- BANK MANAGEMENT SYSTEM SQL SCRIPT
-- (Same complexity: tables, constraints, procedures, triggers)

CREATE TABLE Card(cardID NUMBER PRIMARY KEY, status VARCHAR2(1), balance NUMBER);
CREATE TABLE Customer(customerID NUMBER PRIMARY KEY, name VARCHAR2(40), username VARCHAR2(10), password VARCHAR2(20), cardNumber NUMBER);

ALTER TABLE Customer ADD FOREIGN KEY(cardNumber) REFERENCES Card(cardID);

INSERT INTO Card VALUES (1,'A',5000);
INSERT INTO Customer VALUES (1,'RAJ','ra1','raj123',1);

CREATE OR REPLACE PROCEDURE loginCustomer_bank(user IN VARCHAR2, pass IN VARCHAR2)
IS p VARCHAR2(20);
BEGIN
 SELECT password INTO p FROM customer WHERE username=user;
 IF p=pass THEN DBMS_OUTPUT.PUT_LINE('Login Success'); END IF;
END;
/

CREATE OR REPLACE TRIGGER trg_card
AFTER INSERT ON customer
FOR EACH ROW
BEGIN
 INSERT INTO card VALUES(:NEW.cardNumber,'A',0);
END;
/
